<template>
  <div id="app">
    <TodoApp msg="Welcome to Your Vue.js Todo App" />
  </div>
</template>

<script>
import TodoApp from "./components/TodoApp.vue";

export default {
  components: {
    TodoApp,
  },
};
</script>
